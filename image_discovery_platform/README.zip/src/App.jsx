
import './App.css';
import Dashboard from './Components/LandingPage';

function App() {
  return (
    <div className="App">
    <Dashboard/>
    </div>
  );
}

export default App;
