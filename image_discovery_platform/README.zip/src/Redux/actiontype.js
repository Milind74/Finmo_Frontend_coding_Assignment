//actiontypes for getting the data  succcess,failure,request
export const GETDATA_REQUEST = "GETDATA_REQUEST"
export const GETDATA_SUCCESS = "GETDATA_SUCCESS"
export const GETDATA_FAILURE = "GETDATA_FAILURE"

//actiontypes for searching the data of succcess,failure,request
export const SEARCHDATA_REQUEST = "SEARCHDATA_REQUEST"
export const SEARCHDATA_SUCCESS = "SEARCHDATA_SUCCESS"
export const SEARCHDATA_FAILURE = "SEARCHDATA_FAILURE"